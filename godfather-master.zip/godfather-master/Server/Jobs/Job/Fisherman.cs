﻿using GTANetworkServer;
using GTANetworkShared;
using TheGodfatherGM.Server.User;
using TheGodfatherGM.Data.Enums;
namespace TheGodfatherGM.Server.Jobs.Job
{
    public class Fishing : Script
    {

    }
}