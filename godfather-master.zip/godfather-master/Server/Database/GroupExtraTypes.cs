﻿namespace TheGodfatherGM.Server.DBManager
{
    public class GroupExtraTypes
    {
    }
}