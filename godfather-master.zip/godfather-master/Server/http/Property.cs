﻿using TheGodfatherGM.Data.Extensions;
using GTANetworkServer;
using Newtonsoft.Json.Linq;
using System;
using TheGodfatherGM.Data.Enums;
using TheGodfatherGM.Server.User;

namespace TheGodfatherGM.Server.http
{
    public class Property
    {
        public static void Listener(string server, string url, string post)
        {
            
        }
    }
}
