﻿namespace TheGodfatherGM.Web.Models.GameViewModel.Vehicle
{
    public class VehicleStorageViewModel
    {
       public string socialclub { get; set; }
    }
}
