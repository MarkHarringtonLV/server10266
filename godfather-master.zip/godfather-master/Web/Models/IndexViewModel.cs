﻿namespace TheGodfatherGM.Web.Models
{
    public class IndexViewModel
    {

    }
}
